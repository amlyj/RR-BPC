Instances are grouped by customer numbers (50, 75, 100) and cable-trench ratios (0.5, 1.0, 1.5).
Each instance is contained in the respective folder. For example, instance 'dorchester75' with 75 customers and cable-trench ratio 1.0 can be found in folder 'InstanceSet75\1.0\dorchester75-1.0'.
All constants are specified in file 'constants.txt'.
Each instance file contains the following information:
-cable cost, weight and time matrices;
-trench cost, weight and time matrices;
-vehicle cost and time matrices;
-cable service times;
-deprivation cost per cluster;
-number of customers per cluster (customerNumber.txt);
-number of available vehicles (fleet.txt);
-upper-bound solution (ub.txt);
-optimal solution (sol.txt) -- for optimally solved instances only.